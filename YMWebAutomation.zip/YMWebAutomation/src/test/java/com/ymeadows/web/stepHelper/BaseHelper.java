package com.ymeadows.web.stepHelper;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class BaseHelper {

	@Autowired
	protected WebDriverWait wait;

	@Autowired
	public JavascriptExecutor js;

	public void clickUsingJavaScriptExecutor(WebElement webElement) {
		js.executeScript("arguments[0].click();", webElement);
	}

	public void waitandclick(WebElement webElement) {
		wait.until(ExpectedConditions.elementToBeClickable(webElement));
		webElement.click();
	}

	public void visibilityOf(WebElement webElement) {
		wait.until(ExpectedConditions.visibilityOf(webElement));
	}

	public void invisibilityOf(WebElement webElement) {
		wait.until(ExpectedConditions.invisibilityOf(webElement));
	}

	public void visibilityOfElementLocated(By by) {
		 wait.until(ExpectedConditions.visibilityOfElementLocated(by));
	}
	
	public void invisibilityOfElementLocated(By by) {
		wait.until(ExpectedConditions.invisibilityOfElementLocated(by));
	}

	public void textToBePresentInElement(WebElement webElement, String text) {
		wait.until(ExpectedConditions.textToBePresentInElement(webElement, text));
	}
	
	public void textToBePresentInElement(WebElement webElement, String text,int time) {
		wait.until(ExpectedConditions.textToBePresentInElement(webElement, text));
	}
	
	public WebElement elementToBeClickable(WebElement webElement,int time) {
		return wait.until(ExpectedConditions.elementToBeClickable(webElement));
	}

	public String getRamdomString(String name, int num) {
		return name + RandomStringUtils.randomAlphanumeric(num);
	}

}

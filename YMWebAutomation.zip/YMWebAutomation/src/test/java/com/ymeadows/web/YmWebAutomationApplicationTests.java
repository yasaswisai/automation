package com.ymeadows.web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YmWebAutomationApplicationTests {

	@Test
	void contextLoads() {
	}

}

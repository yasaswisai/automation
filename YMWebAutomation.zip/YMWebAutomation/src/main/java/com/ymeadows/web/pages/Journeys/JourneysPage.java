package com.ymeadows.web.pages.Journeys;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ymeadows.web.pages.BasePage;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@Data
@EqualsAndHashCode(callSuper=false)
public class JourneysPage extends BasePage {

	@FindBy(xpath = "//li[contains(text(),'Journey Path')]")
	private WebElement JourneyPath;

	@FindBy(xpath = "//li[contains(text(),'Junction Path')]")
	private WebElement JunctionPath;

	@FindBy(xpath = "//li[contains(text(),'Fallback Path')]")
	private WebElement FallbackPath;

	@FindBy(css = ".tertiary")
	private WebElement ClickJourneyPathBtn;

	@FindBy(css = ".meta>.inline.edit.name>span.one-line")
	private WebElement JourneyName;

	@FindBy(css = "div.meta>div.inline.edit.desc>span")
	private WebElement JourneyDesc;
	
	@FindBy(css="hgroup>.inline.edit.name>.one-line")
	private WebElement sourceName;
	
	@FindBy(css=".path-type-toggle>aside")
	private WebElement editingUnpublishedDraft;
	
	@FindBy(css="section[class='meta']>div[class='inline edit desc']>span")
	private WebElement sourceDesc;
	
	@FindBy(css=".actions>.tertiary")
	private WebElement publishDraft;
	
	@FindBy(css=".rrt-middle-container")
	private WebElement confirmationAlert;
	
	@FindBy(css=".rrt-middle-container>.rrt-text")
	private WebElement confirmationAlertText;
	
	@FindBy(css=".actions>.tertiary")
	private List<WebElement> publishDraftSize;
	
	@FindBy(css="hgroup>.inline.name")
	private WebElement sourceNameVal;
	
	@FindBy(css=".rrt-message")
	private WebElement deleteConfirmationMessage;
	
	@FindBy(css=".rrt-button.rrt-cancel-btn.toastr-control")
	private WebElement deleteConfirmationCancel;
	
	@FindBy(css=".rrt-button.rrt-ok-btn.toastr-control")
	private WebElement deleteConfirmationOK;
	
	@FindBy(css=".junction_source.step.selected>figure.inner")
	private WebElement junction;
	
	@FindBy(xpath="(//figure[@contenteditable='false'])[1]")
	private WebElement dragAndDropFrom;
	
	@FindBy(xpath="//span[@contenteditable='true']")
	private WebElement dragAndDropTo;
	
	@FindBy(css=".one-line>.label.inactive>figcaption")
	private WebElement intent;
	
	@FindBy(css=".searchbox>input")
	private WebElement searchArea;
	
	@FindBy(css=".resolution.step>ul>li:nth-of-type(2)>figure.add-circle.icon")
	private WebElement reviewAddButton;
	
	@FindBy(xpath="//figcaption[text()='Review']")
	private WebElement review;
	
	@FindBy(css="section.inputs>ul:nth-of-type(1)>li:nth-of-type(1)>div>.one-line")
	private WebElement inputSender;
	
	@FindBy(css="aside>header>.searchbox>input")
	private WebElement searchBox;
	
	@FindBy(css=".submit.primary")
	private WebElement savebtn;
	
	@FindBy(xpath="(//figure[@contenteditable='false'])[1]/figcaption")
	private WebElement dragAndDropFromText;
	
	@FindBy(css="section.inputs>ul:nth-of-type(1)>li:nth-of-type(1)>.inline.edit>.one-line>figure>figcaption")
	private WebElement inputSenderText;
	
	@FindBy(css="section.inputs>ul:nth-of-type(1)>li:nth-of-type(2)>div>.one-line")
	private WebElement inputCreatedDate;
	
	@FindBy(css="section.inputs>ul:nth-of-type(1)>li:nth-of-type(2)>div>.one-line>figure>figcaption")
	private WebElement inputCreatedDateText;
	
	@FindBy(css="section.inputs>ul:nth-of-type(1)>li:nth-of-type(3)>div>.one-line")
	private WebElement inputSubject;
	
	@FindBy(css="section.inputs>ul:nth-of-type(1)>li:nth-of-type(3)>div>.one-line>figure>figcaption")
	private WebElement inputSubjectText;
	
	@FindBy(css="section.inputs>ul:nth-of-type(1)>li:nth-of-type(4)>div>.one-line")
	private WebElement inputAttachment;
	
	@FindBy(css="section.inputs>ul:nth-of-type(1)>li:nth-of-type(5)>div>.one-line")
	private WebElement inputMessage;
	
	@FindBy(css="section.inputs>ul:nth-of-type(1)>li:nth-of-type(5)>div>.one-line>figure>figcaption")
	private WebElement inputMessageText;
	
	@FindBy(css="section.inputs>ul:nth-of-type(1)>li:nth-of-type(6)>div>.one-line")
	private WebElement inputRequestFormat;
	
	@FindBy(css="section.inputs>ul:nth-of-type(1)>li:nth-of-type(7)>div>.one-line")
	private WebElement inputResponse;
	
	@FindBy(css="section.inputs>ul:nth-of-type(1)>li:nth-of-type(8)>div>.one-line")
	private WebElement inputResponseFormat;
	
	@FindBy(css="section.inputs>ul:nth-of-type(1)>li:nth-of-type(9)>div>.one-line")
	private WebElement inputProposedOutcome;
	
	@FindBy(css="section.inputs>ul:nth-of-type(1)>li:nth-of-type(10)>div>.one-line")
	private WebElement inputIntent;
	
	@FindBy(css="section.inputs>ul:nth-of-type(1)>li:nth-of-type(10)>div>.one-line>figure>figcaption")
	private WebElement inputIntentText;
	
	@FindBy(css="section.inputs>ul:nth-of-type(1)>li:nth-of-type(11)>div>.one-line")
	private WebElement inputConfidence;
	
	@FindBy(css="section.inputs>ul:nth-of-type(1)>li:nth-of-type(11)>div>.one-line>figure>figcaption")
	private WebElement inputConfidenceText;
	
	@FindBy(css="section.inputs>ul:nth-of-type(1)>li:nth-of-type(12)>div>.one-line")
	private WebElement inputReviewQueue;
	
	@FindBy(css=".select>select")
	private WebElement reviewQueueDropdown;
	
	@FindBy(css="section.inputs>ul:nth-of-type(2)>li:nth-of-type(1)>div>.one-line")
	private WebElement additionalInformation;
	
	@FindBy(css=".additional-information>li:nth-of-type(1)>div>div.fx-name>.content")
	private WebElement additionalInformationlbl;
	
	@FindBy(css=".additional-information>li:nth-of-type(1)>div>div.fx-value>.content")
	private WebElement additionalInformationValue;
	
	@FindBy(css=".additional-information>li:nth-of-type(1)>div>.fx-more>figure:nth-of-type(2)")
	private WebElement plusIcon;
	
	@FindBy(css=".additional-information>li:nth-of-type(2)>div>div.fx-name>.content")
	private WebElement secondAdditionalInformationlbl;
	
	@FindBy(css=".additional-information>li:nth-of-type(2)>div>div.fx-value>.content")
	private WebElement secondAdditionalInformationValue;
	
	@FindBy(css=".additional-information>li:nth-of-type(2)>div>.fx-more>figure:nth-of-type(2)")
	private WebElement secondplusIcon;
	
	@FindBy(css=".additional-information>li:nth-of-type(3)>div>div.fx-name>.content")
	private WebElement thirdAdditionalInformationlbl;
	
	@FindBy(css=".additional-information>li:nth-of-type(3)>div>div.fx-value>.content")
	private WebElement thirdAdditionalInformationValue;
	
	@FindBy(css=".additional-information>li:nth-of-type(3)>div>.fx-more>figure:nth-of-type(2)")
	private WebElement thirdplusIcon;
	
	@FindBy(css=".proposed-changes>li:nth-of-type(1)>div>div.fx-name>.content")
	private WebElement proposedChangeslbl;
	
	@FindBy(css=".proposed-changes>li:nth-of-type(1)>div>div.fx-value>.content")
	private WebElement proposedChangesValue;
	
	@FindBy(css=".proposed-changes>li:nth-of-type(1)>div>.fx-more>figure:nth-of-type(2)")
	private WebElement proposedChangesPlusIcon;
	
	@FindBy(css=".proposed-changes>li:nth-of-type(2)>div>div.fx-name>.content")
	private WebElement secondProposedChangeslbl;
	
	@FindBy(css=".proposed-changes>li:nth-of-type(2)>div>div.fx-value>.content")
	private WebElement secondProposedChangesValue;
	
	@FindBy(css=".flyout-collapse.icon")
	private WebElement collapseIcon;
	
	@FindBy(css="div.fx-value.disable-typing>figure.delete.icon")
	private WebElement deleteIcon;
	
	@FindBy(xpath="(//figure[@class='close icon'])[3]")
	private WebElement closeIcon;
	
	@FindBy(css="div.junction_source.step.selected>ul.menu>li.ne>figure.edit.icon")
	private WebElement editIcon;
	
	@FindBy(xpath="//figcaption[contains(text(),'Update Salesforce Case Fields')]")
	private WebElement updateSalesForceCaseField;
	
	@FindBy(css="section.inputs>ul:nth-of-type(1)>li:nth-of-type(1)>div>.one-line")
	private WebElement caseIdInput;
	
	@FindBy(css="section.inputs>ul:nth-of-type(1)>li:nth-of-type(1)>div>.one-line>figure>figcaption")
	private WebElement caseIdInputText;
	
	@FindBy(css="section.inputs>ul:nth-of-type(1)>li:nth-of-type(5)>div>.one-line")
	private WebElement caseStatusInput;
	
	@FindBy(css="section.inputs>ul>li:nth-of-type(5)>div>span")
	private WebElement caseStatusInputText;
	
	@FindBy(css="section.inputs>ul:nth-of-type(1)>li:nth-of-type(6)>div>.one-line")
	private WebElement casePriorityInput;
	
	@FindBy(css="section.inputs>ul>li:nth-of-type(6)>div>span")
	private WebElement casePriorityInputText;
	
	@FindBy(css="section.inputs>ul:nth-of-type(1)>li:nth-of-type(7)>div>.one-line")
	private WebElement caseTypeInput;
	
	@FindBy(css="section.inputs>ul>li:nth-of-type(7)>div>span")
	private WebElement caseTypeInputText;

	@FindBy(css="#journey-library>main>details:nth-of-type(2)>ul>li:nth-of-type(3)")
	private WebElement salesForceUpdateCaseTypeField;
	
	@FindBy(css="section.inputs>ul:nth-of-type(1)>li:nth-of-type(2)>div>.one-line")
	private WebElement salesForceUpdateCaseTypeInput;
	
	@FindBy(css="section.inputs>ul>li:nth-of-type(2)>div>span")
	private WebElement salesForceUpdateCaseTypeInputText;
	
	@FindBy(css="#journey-library>main>details:nth-of-type(2)>ul>li:nth-of-type(4)")
	private WebElement salesForceUpdateQueueField;
	
	@FindBy(css="section.inputs>ul:nth-of-type(1)>li:nth-of-type(2)>div>.one-line")
	private WebElement salesForceUpdateQueueInput;
	
	@FindBy(css="section.inputs>ul>li:nth-of-type(2)>div>span")
	private WebElement salesForceUpdateQueueInputText;
	
}

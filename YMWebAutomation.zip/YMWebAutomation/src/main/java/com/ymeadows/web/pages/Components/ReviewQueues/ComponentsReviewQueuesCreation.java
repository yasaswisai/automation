package com.ymeadows.web.pages.Components.ReviewQueues;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ymeadows.web.pages.BasePage;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@Data
@EqualsAndHashCode(callSuper = false)
public class ComponentsReviewQueuesCreation extends BasePage {

	@FindBy(xpath = "//h1[contains(text(),'All Review Queues')]")
	private WebElement AllReviewQueue;

	@FindBy(css = ".inputs>.inline.edit.focus.name>div")
	private WebElement ReviewQueueName;

	@FindBy(css = ".inputs>.inline.edit.name>span")
	private WebElement UpdateReviewQueueName;

	@FindBy(css = ".inputs>.inline.edit.focus.description>div")
	private WebElement ReviewQueueDescription;
	
	@FindBy(css = ".inputs>.inline.edit.description>span")
	private WebElement UpdateReviewQueueDescription;

	@FindBy(xpath = "//button[contains(text(),'Save')]")
	private WebElement SaveReviewQueue;

	@FindBy(css = ".rrt-middle-container>.rrt-text")
	private WebElement ReviewQueueSuccessMessageElement;

	private By ReviewQueueSuccess = By.cssSelector(".rrt-middle-container");

	private By ReviewQueueSuccessMessage = By.cssSelector(".rrt-middle-container>.rrt-text");

	@FindBy(css = ".back.icon")
	private WebElement BackIcon;

}

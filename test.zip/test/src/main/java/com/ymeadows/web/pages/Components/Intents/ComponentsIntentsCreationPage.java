package com.ymeadows.web.pages.Components.Intents;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ymeadows.web.pages.BasePage;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@Data
@EqualsAndHashCode(callSuper = false)
public class ComponentsIntentsCreationPage extends BasePage {

	@FindBy(xpath = "//h1[contains(text(),'All Intents')]")
	private WebElement AllIntents;

	@FindBy(css = ".inputs>.inline.edit.focus.name>div")
	private WebElement IntentName;

	@FindBy(css = ".inputs>.inline.edit.name>span")
	private WebElement UpdateIntentName;

	@FindBy(css = ".inputs>.inline.edit.focus.description>div")
	private WebElement IntentDescription;

	@FindBy(css = ".inputs>.inline.edit.description>span")
	private WebElement UpdateIntentDescription;

	@FindBy(xpath = "//button[contains(text(),'Save')]")
	private WebElement SaveIntent;

	@FindBy(css = ".rrt-middle-container>.rrt-text")
	private WebElement IntentMessageElement;

	private By IntentSuccess = By.cssSelector(".rrt-middle-container");

	private By IntentMessageBy = By.cssSelector(".rrt-middle-container>.rrt-text");

	@FindBy(css = ".back.icon")
	private WebElement BackIcon;

}

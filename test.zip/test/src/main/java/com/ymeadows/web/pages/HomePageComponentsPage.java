package com.ymeadows.web.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@Data
@EqualsAndHashCode(callSuper=false)
public class HomePageComponentsPage extends BasePage {

	@FindBy(xpath = "//figcaption[contains(text(),'Dashboard')]")
	private WebElement Dashboard;

	@FindBy(xpath = "//figcaption[contains(text(),'Components')]")
	private WebElement Components;
	
	@FindBy(xpath = "//figcaption[contains(text(),'Journeys')]")
	private WebElement Journeys;

	@FindBy(xpath = "//figcaption[contains(text(),'Labeling')]")
	private WebElement Labeling;

	@FindBy(xpath = "//figcaption[contains(text(),'Reviews')]")
	private WebElement Reviews;

}

package com.ymeadows.web.pages.Components.Intents;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ymeadows.web.pages.BasePage;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@Data
@EqualsAndHashCode(callSuper = false)
public class ComponentsIntentsListPage extends BasePage {

	@FindBy(xpath = "//h3[contains(text(),'Intents')]")
	private WebElement ComponentsIntents;

	@FindBy(xpath = "//h2[contains(text(),'Intents')]")
	private WebElement HeaderIntents;

	@FindBy(xpath = "//button[contains(text(),'+ Intent')]")
	private WebElement PlusIntent;

	@FindBy(css = ".rrt-message")
	private WebElement deleteIntentMessage;

	@FindBy(xpath = "//button[contains(text(),'cancel')]")
	private WebElement deleteCancel;

	@FindBy(xpath = "//button[contains(text(),'ok')]")
	private WebElement deleteOk;

}

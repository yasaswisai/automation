package com.ymeadows.web.pages.Components.ReviewQueues;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ymeadows.web.pages.BasePage;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@Data
@EqualsAndHashCode(callSuper = false)
public class ComponentsReviewQueuesListPage extends BasePage {

	@FindBy(xpath = "//h3[contains(text(),'Review Queues')]")
	private WebElement ComponentsReviewQueues;

	@FindBy(xpath = "//h2[contains(text(),'Review Queues')]")
	private WebElement HeaderReviewQueues;

	@FindBy(xpath = "//button[contains(text(),'+ Review Queue')]")
	private WebElement PlusReviewQueue;

	@FindBy(css = ".rrt-message")
	private WebElement deleteReviewQueueMessage;

	@FindBy(xpath = "//button[contains(text(),'cancel')]")
	private WebElement deleteCancel;

	@FindBy(xpath = "//button[contains(text(),'ok')]")
	private WebElement deleteOk;

}

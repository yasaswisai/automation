package com.ymeadows.web.config;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;

@Configuration
public class ActionsConfig {
	
	@Bean
	public Actions getActions(WebDriver driver) {
		return new Actions(driver);
	}

}

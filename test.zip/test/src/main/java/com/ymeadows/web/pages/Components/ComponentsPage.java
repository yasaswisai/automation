package com.ymeadows.web.pages.Components;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ymeadows.web.pages.BasePage;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@Data
@EqualsAndHashCode(callSuper=false)
public class ComponentsPage extends BasePage {
	
	@FindBy(xpath = "//h1[contains(text(),'Components')]")
	private WebElement Components;
	
	@FindBy(xpath = "//h3[text()='Intents']")
	private WebElement Intents;
	
	@FindBy(css = "#components-intents>header>span>h2")
	private WebElement Intentslbl;
	
	@FindBy(css = ".tertiary")
	private WebElement Intentbtn;
	
	@FindBy(xpath = "//h1[text()='All Intents']")
	private WebElement AllIntentlbl;
	
	@FindBy(css = ".inputs>.inline.edit.focus.name>div")
	private WebElement IntentNameInput;
	
	@FindBy(css = ".inputs>.inline.edit.focus.description>div")
	private WebElement IntentDescriptionInput;
	
	@FindBy(css = ".submit.primary")
	private WebElement SaveBtn;
	
	@FindBy(css=".rrt-middle-container")
	private WebElement confirmationAlert;
	
	@FindBy(css=".rrt-middle-container>.rrt-text")
	private WebElement confirmationAlertText;
	
	@FindBy(css=".inputs>.inline.edit.name>.one-line")
	private WebElement enteredIntentName;
	
	@FindBy(css=".inputs>.inline.edit.description>.one-line")
	private WebElement enteredIntentDesc;
	
	@FindBy(css=".back.icon")
	private WebElement backIcon;
	
	@FindBy(css = ".inputs>.inline.edit.name>.one-line")
	private WebElement updatedIntentNameInput;
	
	@FindBy(css = ".inputs>.inline.edit.description>.one-line")
	private WebElement updatedIntentDescriptionInput;
	
	@FindBy(css=".rrt-message")
	private WebElement deleteConfirmationMessage;
	
	@FindBy(css=".rrt-button.rrt-cancel-btn.toastr-control")
	private WebElement deleteConfirmationCancel;
	
	@FindBy(css=".rrt-button.rrt-ok-btn.toastr-control")
	private WebElement deleteConfirmationOK;
	
	
}


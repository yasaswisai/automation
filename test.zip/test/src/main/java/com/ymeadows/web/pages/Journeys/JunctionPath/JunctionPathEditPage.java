package com.ymeadows.web.pages.Journeys.JunctionPath;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ymeadows.web.pages.BasePage;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
@Data
@EqualsAndHashCode(callSuper = false)
public class JunctionPathEditPage extends BasePage {

	@FindBy(css = "div[class='meta'] span[class='one-line']")
	private WebElement JucntionPathName;

	@FindBy(css = "div[class='meta'] div[class='inline edit desc'] span")
	private WebElement JucntionPathDesc;

	@FindBy(css = "button[class='tertiary']")
	private WebElement JunctionPathPublishDraft;

	@FindBy(xpath = "//li[normalize-space()='Draft']")
	private WebElement JunctionPathDraftButton;

	@FindBy(xpath = "//aside[normalize-space()='You are editing an unpublished draft']")
	private WebElement JunctionPathUnpublishedDraft;

	@FindBy(xpath = "//li[normalize-space()='Live']")
	private WebElement JunctionPathLiveButton;

	@FindBy(xpath = "//aside[normalize-space()='You are viewing the published version']")
	private WebElement JunctionPathPublishedVersion;

}

package com.ymeadows.web.config;

import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.ProfilesIni;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;

import io.github.bonigarcia.wdm.WebDriverManager;
import net.lightbody.bmp.BrowserMobProxy;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.client.ClientUtil;

@Configuration
public class WebDriverConfig {

	@Value("${clientID}")
	protected String clientID;

	@Value("${clientSecretID}")
	protected String clientSecretID;

	@Bean
	@Scope("browserscope")
	@ConditionalOnProperty(name = "browser", havingValue = "chrome")
	public WebDriver getChromeDriver() {

		BrowserMobProxy proxy = new BrowserMobProxyServer();

		Proxy seleniumProxy = getProxy(proxy);

		ChromeOptions opts = new ChromeOptions();

		// Setting up Proxy for chrome
		String proxyOption = "--proxy-server=" + seleniumProxy.getHttpProxy();
		opts.addArguments(proxyOption);
		opts.addArguments("--ignore-ssl-errors=yes");
		opts.addArguments("--ignore-certificate-errors");

		WebDriverManager.chromedriver().setup();
		return new ChromeDriver(opts);

	}

	@Bean
	@Scope("browserscope")
	@ConditionalOnProperty(name = "browser", havingValue = "firefox")
	public WebDriver getFirefoxDriver() {
		BrowserMobProxy proxy = new BrowserMobProxyServer();

		Proxy seleniumProxy = getProxy(proxy);
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(CapabilityType.PROXY, seleniumProxy);

		ProfilesIni profile = new ProfilesIni();
		FirefoxProfile myprofile = profile.getProfile("default");
		myprofile.setAcceptUntrustedCertificates(true);
		myprofile.setAssumeUntrustedCertificateIssuer(false);

		myprofile.setPreference("network.proxy.type", 1);
		myprofile.setPreference("network.proxy.http", "localhost");
		myprofile.setPreference("network.proxy.http_port", proxy.getPort());
		myprofile.setPreference("network.proxy.ssl", "localhost");
		myprofile.setPreference("network.proxy.ssl_port", proxy.getPort());

		// Setting up Proxy for firefox
		FirefoxOptions opts = new FirefoxOptions();
		String proxyOption = "--proxy-server=" + seleniumProxy.getHttpProxy();
//		opts.addArguments(proxyOption);
		opts.addArguments("--ignore-ssl-errors=yes");
		opts.addArguments("--ignore-certificate-errors");
		opts.merge(capabilities);
		opts.setProfile(myprofile);

		WebDriverManager.firefoxdriver().setup();
		return new FirefoxDriver(opts);
	}

	public Proxy getProxy(BrowserMobProxy proxy) {

		proxy.setTrustAllServers(true);
		proxy.start(0);
		Proxy seleniumProxy = ClientUtil.createSeleniumProxy(proxy);

		// put our custom header to each request
		proxy.addRequestFilter((request, contents, messageInfo) -> {
			request.headers().add("CF-Access-Client-Id", clientID);
			request.headers().add("CF-Access-Client-Secret", clientSecretID);
			return null;
		});

		return seleniumProxy;
	}
}

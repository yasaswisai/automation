
import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.client.ClientUtil;
import net.lightbody.bmp.core.har.Har;
import net.lightbody.bmp.core.har.HarEntry;
import net.lightbody.bmp.proxy.CaptureType;

public class test {

	private static WebDriver driver;
	private static BrowserMobProxyServer proxyServer;

	@BeforeTest
	public static void setup() {
		WebDriverManager.chromedriver().setup();

		// start the proxy
		proxyServer = new BrowserMobProxyServer();

		proxyServer.setTrustAllServers(true);
		proxyServer.start(0);
		Proxy seleniumProxy = ClientUtil.createSeleniumProxy(proxyServer);

		// put our custom header to each request
		proxyServer.addRequestFilter((request, contents, messageInfo) -> {
			request.headers().add("CF-Access-Client-Id", "400ba946a7638cd8e941cc9e786b8277.access");
			request.headers().add("CF-Access-Client-Secret",
					"5d82a2ab6d76155bde63ed545b6632d84340f4bf0a3d0e80622a0a27ec4faaa1");
			return null;
		});

		// capture content as a HAR (HTTP Archive)
		// to process when test is complete
		proxyServer.enableHarCaptureTypes(CaptureType.REQUEST_CONTENT, CaptureType.RESPONSE_CONTENT);
		proxyServer.newHar();

		String proxyOption = "--proxy-server=" + seleniumProxy.getHttpProxy();

		final ChromeOptions options = new ChromeOptions();
		options.addArguments(proxyOption);
		options.setAcceptInsecureCerts(true);
		driver = new ChromeDriver(options);

	}

	@Test
	public void captureTraffic() throws Exception {

		driver.manage().window().maximize();

		driver.get("https://tierzero-qa.ymeadows.com/");

		driver.findElement(By.id("username")).sendKeys("automation_user_admin1");
		driver.findElement(By.id("password")).sendKeys("automation_user_admin1");

		WebElement login = driver.findElement(By.id("kc-login"));

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", login);
		
		Thread.sleep(3000);
		driver.findElement(By.xpath("//figcaption[contains(text(),'Components')]")).click();

		// get all the https messages as Har responses
		final Har httpMessages = proxyServer.getHar();
		for (HarEntry httpMessage : httpMessages.getLog().getEntries()) {

			// check no errors on the XHR requests
			if (httpMessage.getRequest().getUrl().contains("/messageset")) {
				assertEquals(200, httpMessage.getResponse().getStatus());

				// just to show something happened
				System.out.println("Request:");
				System.out.println(httpMessage.getRequest().getUrl());
				System.out.println("Response:");
				System.out.println(httpMessage.getResponse().getContent().getText());
			}
		}

	}

	@AfterTest
	public static void tearDown() {
		driver.quit();
		proxyServer.abort();
	}

}

package com.ymeadows.web.stepHelper;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.ymeadows.web.pages.Components.Intents.ComponentsIntentsCreationPage;
import com.ymeadows.web.pages.Components.Intents.ComponentsIntentsListPage;

public class ComponentsIntentsStepHelper {

	@Autowired
	protected BaseHelper baseHelper;

	@Autowired
	protected Actions actions;

	@Autowired
	protected WebDriver driver;

	@Autowired
	protected ComponentsIntentsListPage componentsIntentsListPage;

	@Autowired
	protected ComponentsIntentsCreationPage componentsIntentsCreationPage;

	@Value("${ymedwos.web}")
	protected String ymeadowsweburl;

	protected String intentName;
	protected String intentDesc;

}

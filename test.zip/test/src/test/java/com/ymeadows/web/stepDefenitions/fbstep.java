package com.ymeadows.web.stepDefenitions;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.beans.factory.annotation.Autowired;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class fbstep {

	@Autowired
	WebDriver driver;

	@Autowired
	WebDriverWait wait;

	@Given("user opens facebook")
	public void user_opens_facebook() {
		driver.manage().window().maximize();
		driver.get("https://tierzero-qa.ymeadows.com/");
	}

	@Given("user enters id and pwd")
	public void user_enters_id_and_pwd() {
		driver.findElement(By.id("username")).sendKeys("automation_user_admin1");
		driver.findElement(By.id("password")).sendKeys("automation_user_admin1");

	}

	@Then("user verfies url")
	public void user_verfies_url() throws InterruptedException {
		WebElement login = driver.findElement(By.id("kc-login"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", login);

		Thread.sleep(2000);

		waitandclick(driver.findElement(By.xpath("//figcaption[contains(text(),'Dashboard')]")));
		waitandclick(driver.findElement(By.xpath("//figcaption[contains(text(),'Journeys')]")));
		
		Thread.sleep(2000);
		
		waitandclick(driver.findElement(By.xpath("//li[contains(text(),'Junction Path')]")));
		waitandclick(driver.findElement(By.xpath("//li[contains(text(),'Fallback Path')]")));

	}

	public void waitandclick(WebElement webElement) {
		wait.until(ExpectedConditions.elementToBeClickable(webElement));
		webElement.click();
	}

}

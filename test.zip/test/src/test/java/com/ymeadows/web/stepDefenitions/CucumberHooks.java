package com.ymeadows.web.stepDefenitions;

import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import io.cucumber.java.After;

public class CucumberHooks {

	@Autowired
	private ApplicationContext applicationContext;


	@After
	public void afterScenario() {
		this.applicationContext.getBean(WebDriver.class).quit();
	}

}

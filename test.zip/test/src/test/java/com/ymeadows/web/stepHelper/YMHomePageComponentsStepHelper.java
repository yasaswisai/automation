package com.ymeadows.web.stepHelper;

import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;

import com.ymeadows.web.pages.HomePageComponentsPage;
import com.ymeadows.web.pages.LoginPage;
import com.ymeadows.web.pages.Components.ComponentsPage;
import com.ymeadows.web.pages.Dashboard.DashboardPage;
import com.ymeadows.web.pages.Journeys.JourneysPage;
import com.ymeadows.web.pages.Labeling.LabelingPage;
import com.ymeadows.web.pages.Reviews.ReviewPage;

@SpringBootTest
public class YMHomePageComponentsStepHelper {

	@Autowired
	protected HomePageComponentsPage homePage;

	@Autowired
	protected LoginPage loginPage;

	@Autowired
	protected DashboardPage dashboardPage;

	@Autowired
	protected ComponentsPage componentsPage;

	@Autowired
	protected JourneysPage journeysPage;

	@Autowired
	protected LabelingPage labelingPage;

	@Autowired
	protected ReviewPage reviewPage;

	@Autowired
	protected WebDriver driver;

	@Autowired
	protected BaseHelper baseHelper;

	@Value("${ymedwos.web}")
	protected String ymeadowsweburl;

	@Value("${ymeadows.username}")
	protected String loginUserName;

	@Value("${ymeadows.password}")
	protected String loginPassword;

}

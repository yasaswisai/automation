package com.ymeadows.web.stepDefenitions;

import static org.testng.Assert.assertEquals;

import com.ymeadows.web.stepHelper.YMHomePageComponentsStepHelper;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class YMHomePageComponentsStep extends YMHomePageComponentsStepHelper {

	@Given("User Logs in to Y Meadows")
	public void user_Logs_in_to_Y_Meadows() {
		driver.manage().window().maximize();
		driver.get(ymeadowsweburl);
		loginPage.getUsername().sendKeys(loginUserName);
		loginPage.getPassword().sendKeys(loginPassword);

		baseHelper.clickUsingJavaScriptExecutor(loginPage.getLogin());
	}

	@When("User clicks on Dashboard")
	public void user_clicks_on_Dashboard() throws InterruptedException {
		baseHelper.waitandclick(homePage.getDashboard());
	}

	@Then("User is landed on DashBoardPage")
	public void user_is_landed_on_DashBoardPage() {
		baseHelper.visibilityOf(dashboardPage.getWelcome());
		assertEquals(ymeadowsweburl + "dashboard", driver.getCurrentUrl());
	}

	@When("User clicks on Components")
	public void user_clicks_on_Components() {
		baseHelper.waitandclick(homePage.getComponents());
	}

	@Then("User is landed on ComponentsPage")
	public void user_is_landed_on_ComponentsPage() {
		baseHelper.visibilityOf(componentsPage.getComponents());
		assertEquals(ymeadowsweburl + "components", driver.getCurrentUrl());
	}

	@When("User clicks on Journeys")
	public void user_clicks_on_Journeys() {
		baseHelper.waitandclick(homePage.getJourneys());
	}

	@Then("User is landed on JourneysPage")
	public void user_is_landed_on_JourneysPage() {
		baseHelper.visibilityOf(journeysPage.getJourneyPath());
		assertEquals(ymeadowsweburl + "journeys", driver.getCurrentUrl());
	}

	@When("User clicks on Labeling")
	public void user_clicks_on_Labeling() {
		baseHelper.waitandclick(homePage.getLabeling());
	}

	@Then("User is landed on LabelingPage")
	public void user_is_landed_on_LabelingPage() {
		baseHelper.visibilityOf(labelingPage.getLabellingIntentsHeader());
		assertEquals(ymeadowsweburl + "labeling", driver.getCurrentUrl());
	}

	@When("User clicks on Reviews")
	public void user_clicks_on_Reviews() {
		baseHelper.waitandclick(homePage.getReviews());
	}

	@Then("User is landed on ReviewsPage")
	public void user_is_landed_on_ReviewsPage() {
		baseHelper.visibilityOf(reviewPage.getReviewModule());
		assertEquals(ymeadowsweburl + "reviews", driver.getCurrentUrl());
	}

}

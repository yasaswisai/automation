package com.ymeadows.web.stepDefenitions;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class googlestep {

	@Autowired
	WebDriver driver;
	
	@Autowired
	WebDriverWait wait;

	@Given("user opens google")
	public void user_opens_google() {
		driver.manage().window().maximize();
		driver.get("https://tierzero-qa.ymeadows.com/");
	}

	@And("user enters keyword")
	public void user_enters_keyword() {
		driver.findElement(By.id("username")).sendKeys("automation_user_admin1");
		driver.findElement(By.id("password")).sendKeys("automation_user_admin1");
		
	}

	@Then("user clicks on search")
	public void user_clicks_on_search() throws InterruptedException {
		WebElement login = driver.findElement(By.id("kc-login"));
        JavascriptExecutor js = (JavascriptExecutor)driver;		
		js.executeScript("arguments[0].click();", login);
		
		Thread.sleep(5000);
		
		waitandclick(driver.findElement(By.xpath("//figcaption[contains(text(),'Dashboard')]")));
		waitandclick(driver.findElement(By.xpath("//figcaption[contains(text(),'Components')]")));
		waitandclick(driver.findElement(By.xpath("//figcaption[contains(text(),'Journeys')]")));
		waitandclick(driver.findElement(By.xpath("//figcaption[contains(text(),'Labeling')]")));

	}

	
	
	public void waitandclick(WebElement webElement) {
		wait.until(ExpectedConditions.elementToBeClickable(webElement));
		webElement.click();
	}
}

package com.ymeadows.web.stepHelper;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.ymeadows.web.pages.Components.ReviewQueues.ComponentsReviewQueuesCreationPage;
import com.ymeadows.web.pages.Components.ReviewQueues.ComponentsReviewQueuesListPage;

public class ComponentReviewQueuesStepHelper {

	@Autowired
	protected BaseHelper baseHelper;

	@Autowired
	protected Actions actions;

	@Autowired
	protected WebDriver driver;

	@Autowired
	protected ComponentsReviewQueuesListPage componentsReviewQueuesListPage;

	@Autowired
	protected ComponentsReviewQueuesCreationPage componentsReviewQueuesCreationPage;

	@Value("${ymedwos.web}")
	protected String ymeadowsweburl;

	protected String reviewQueueName;
	protected String reviewQueueDesc;

}

package com.ymeadows.web.stepDefenitions;

import static org.testng.Assert.assertEquals;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.ymeadows.web.stepHelper.ComponentsIntentsStepHelper;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ComponentsIntentsStep extends ComponentsIntentsStepHelper {

	@When("User clicks on the Intents")
	public void user_clicks_on_the_Intents() {
		baseHelper.waitandclick(componentsIntentsListPage.getComponentsIntents());
	}

	@Then("User is landed on Intent Page")
	public void user_is_landed_on_Intent_Page() {
		baseHelper.visibilityOf(componentsIntentsListPage.getHeaderIntents());
		assertEquals(ymeadowsweburl + "components/intents", driver.getCurrentUrl());
	}

	@When("User clicks on the + Intent button")
	public void user_clicks_on_the_Intent_button() {
		baseHelper.waitandclick(componentsIntentsListPage.getPlusIntent());
	}

	@Then("User lands on the Intent creation page")
	public void user_lands_on_the_Intent_creation_page() {
		baseHelper.visibilityOf(componentsIntentsCreationPage.getAllIntents());
		assertEquals(ymeadowsweburl + "components/intents/create", driver.getCurrentUrl());
	}

	@And("User enters Intent Name, Intent Description")
	public void user_enters_Intent_Name_Intent_Description(io.cucumber.datatable.DataTable dataTable) {

		List<java.util.Map<String, String>> data = dataTable.asMaps(String.class, String.class);

		for (int i = 0; i < data.size(); i++) {
			intentName = baseHelper.getRamdomString(data.get(0).get("IntentName"), 3);
			intentDesc = baseHelper.getRamdomString(data.get(0).get("IntentDescription"), 3);

			baseHelper.waitandclick(componentsIntentsCreationPage.getIntentName());
			actions.sendKeys(intentName).perform();

			baseHelper.waitandclick(componentsIntentsCreationPage.getIntentDescription());
			actions.sendKeys(intentDesc).perform();

		}
	}

	@And("Verify Intents Success Message")
	public void verify_IntentsSuccess_Message() {
		baseHelper.visibilityOfElementLocated(componentsIntentsCreationPage.getIntentSuccess());

		assertEquals(componentsIntentsCreationPage.getIntentMessageElement().getText(),
				"Your intent has been created and is now available for use");

		baseHelper.invisibilityOfElementLocated(componentsIntentsCreationPage.getIntentSuccess());

		baseHelper.waitandclick(componentsIntentsCreationPage.getBackIcon());

	}

	@And("User clicks on IntentSave")
	public void user_clicks_on_Save() {
		baseHelper.waitandclick(componentsIntentsCreationPage.getSaveIntent());
	}

	@And("Verify the Intent Name and Description in Intents list")
	public void verify_the_Intent_Name_and_Description_in_Intents_list() {

		WebElement intentNameElement = driver.findElement(By.xpath("//figcaption[text()='" + intentName + "']"));
		WebElement intentDescElement = driver.findElement(By.xpath("//p[contains(text(),'" + intentDesc + "')]"));

		baseHelper.textToBePresentInElement(intentNameElement, intentName);

		Assert.assertEquals(intentNameElement.getText(), intentName);
		Assert.assertEquals(intentDescElement.getText(), intentDesc);
	}

	@When("User clicks on the intent open button")
	public void user_clicks_on_the_open_button() {

		WebElement openintentNameElement = driver
				.findElement(By.xpath("(//figcaption[text()='" + intentName + "']/../../following::td)[2]/ul/li[1]"));

		baseHelper.waitandclick(openintentNameElement);
	}

	@And("Update the Intent Name and Description")
	public void update_the_Intent_Name_and_Description(io.cucumber.datatable.DataTable dataTable) {
		List<java.util.Map<String, String>> data = dataTable.asMaps(String.class, String.class);

		for (int i = 0; i < data.size(); i++) {
			intentName = baseHelper.getRamdomString(data.get(0).get("UpdatedIntentName"), 3);
			intentDesc = baseHelper.getRamdomString(data.get(0).get("UpdatedIntentDescription"), 3);

			baseHelper.waitandclick(componentsIntentsCreationPage.getUpdateIntentName());
			actions.keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).build().perform();
			actions.sendKeys(Keys.BACK_SPACE).build().perform();
			actions.sendKeys(intentName).perform();
			actions.sendKeys(Keys.TAB).perform();

			WebElement updatedintentNameName = driver
					.findElement(By.cssSelector("div[class='inline edit name'] span[class='one-line']"));
			baseHelper.textToBePresentInElement(updatedintentNameName, intentName);
			Assert.assertEquals(updatedintentNameName.getText(), intentName);

			baseHelper.waitandclick(componentsIntentsCreationPage.getUpdateIntentDescription());
			actions.keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).build().perform();
			actions.sendKeys(Keys.BACK_SPACE).build().perform();
			actions.sendKeys(intentDesc).perform();
			actions.sendKeys(Keys.TAB).perform();

			WebElement updatedintentDescDesc = driver
					.findElement(By.cssSelector("div[class='inline edit description'] span[class='one-line']"));
			baseHelper.textToBePresentInElement(updatedintentDescDesc, intentDesc);
			Assert.assertEquals(updatedintentDescDesc.getText(), intentDesc);

		}
		baseHelper.waitandclick(componentsIntentsCreationPage.getBackIcon());

	}

	@And("User deletes created Intent")
	public void user_deletes_created_Intent() throws InterruptedException {
		Thread.sleep(5000);
		By deleteIntentNameBy = By.xpath("//li[@data-name='" + intentName + "']");

		WebElement deleteIntentNameElement = driver.findElement(deleteIntentNameBy);

		String deleteIntentMessage = "Are you sure you want to delete " + intentName
				+ "? This is a permanent action and it will no longer be unavailable for your entire organization.";

		baseHelper.visibilityOfElementLocated(deleteIntentNameBy);
		baseHelper.waitandclick(deleteIntentNameElement);

		baseHelper.textToBePresentInElement(componentsIntentsListPage.getDeleteIntentMessage(), deleteIntentMessage);

		baseHelper.waitandclick(componentsIntentsListPage.getDeleteOk());
		baseHelper.invisibilityOfElementLocated(deleteIntentNameBy);
	}

	@And("User enters the existing Intent Name and Description")
	public void user_enters_the_existing_Intent_Name_and_Description_and_clicks_on_save() {
		baseHelper.waitandclick(componentsIntentsCreationPage.getIntentName());
		actions.sendKeys(intentName).perform();

		baseHelper.waitandclick(componentsIntentsCreationPage.getIntentDescription());
		actions.sendKeys(intentDesc).perform();
	}

	@Then("User should see the popup with error message")
	public void user_should_see_the_popup_with_error_message() {
		baseHelper.visibilityOfElementLocated(componentsIntentsCreationPage.getIntentMessageBy());

		assertEquals(componentsIntentsCreationPage.getIntentMessageElement().getText(),
				"It looks like we encountered a hiccup. Please try again.");

		baseHelper.invisibilityOfElementLocated(componentsIntentsCreationPage.getIntentMessageBy());

		baseHelper.waitandclick(componentsIntentsCreationPage.getBackIcon());
	}
	

}

package com.ymeadows.web;

import org.junit.jupiter.api.Test;

//@SpringBootTest
class UiAutomationDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.ymeadows.web.stepDefenitions;

import static org.testng.Assert.assertEquals;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.ymeadows.web.stepHelper.ComponentReviewQueuesStepHelper;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ComponentReviewQueuesStep extends ComponentReviewQueuesStepHelper {

	@When("User clicks on the Review Queues")
	public void user_clicks_on_the_Review_Queues() {
		baseHelper.waitandclick(componentsReviewQueuesListPage.getComponentsReviewQueues());
	}

	@Then("User is landed on Review Queues Page")
	public void user_is_landed_on_Review_Queues_Page() {
		baseHelper.visibilityOf(componentsReviewQueuesListPage.getHeaderReviewQueues());
		assertEquals(ymeadowsweburl + "components/review-queues", driver.getCurrentUrl());
	}

	@When("User clicks on the +ReviewQueue button")
	public void user_clicks_on_the_ReviewQueue_button() {
		baseHelper.waitandclick(componentsReviewQueuesListPage.getPlusReviewQueue());
	}

	@Then("User lands on the ReviewQueue creation page")
	public void user_lands_on_the_ReviewQueue_creation_page() {
		baseHelper.visibilityOf(componentsReviewQueuesCreationPage.getAllReviewQueue());
		assertEquals(ymeadowsweburl + "components/review-queues/create", driver.getCurrentUrl());
	}

	@And("User enters ReviewQueue Name, ReviewQueue Description")
	public void user_enters_ReviewQueue_Name_ReviewQueue_Description(io.cucumber.datatable.DataTable dataTable) {

		List<java.util.Map<String, String>> data = dataTable.asMaps(String.class, String.class);

		for (int i = 0; i < data.size(); i++) {
			reviewQueueName = baseHelper.getRamdomString(data.get(0).get("ReviewQueueName"), 3);
			reviewQueueDesc = baseHelper.getRamdomString(data.get(0).get("ReviewQueueDescription"), 3);

			baseHelper.waitandclick(componentsReviewQueuesCreationPage.getReviewQueueName());
			actions.sendKeys(reviewQueueName).perform();

			baseHelper.waitandclick(componentsReviewQueuesCreationPage.getReviewQueueDescription());
			actions.sendKeys(reviewQueueDesc).perform();

		}
	}

	@And("User clicks on ReviewsQueueSave")
	public void user_clicks_on_Save() {
		baseHelper.waitandclick(componentsReviewQueuesCreationPage.getSaveReviewQueue());
	}

	@And("Verify ReviewQueueSuccess Message")
	public void verify_ReviewQueueSuccess_Message() {

		baseHelper.visibilityOfElementLocated(componentsReviewQueuesCreationPage.getReviewQueueSuccess());

		assertEquals(componentsReviewQueuesCreationPage.getReviewQueueSuccessMessageElement().getText(),
				"Your Review Queue has been created and is now available for use");

		baseHelper.invisibilityOfElementLocated(componentsReviewQueuesCreationPage.getReviewQueueSuccess());

		baseHelper.waitandclick(componentsReviewQueuesCreationPage.getBackIcon());

	}

	@And("Verify the ReviewQueueName Name and Description in ReviewQueue list")
	public void verify_the_ReviewQueueName_Name_and_Description_in_ReviewQueue_list() {

		WebElement reviewQueueNameElement = driver
				.findElement(By.xpath("//figcaption[text()='" + reviewQueueName + "']"));
		WebElement reviewQueueDescElement = driver
				.findElement(By.xpath("//p[contains(text(),'" + reviewQueueDesc + "')]"));

		baseHelper.textToBePresentInElement(reviewQueueNameElement, reviewQueueName);

		Assert.assertEquals(reviewQueueNameElement.getText(), reviewQueueName);
		Assert.assertEquals(reviewQueueDescElement.getText(), reviewQueueDesc);

	}

	@When("User clicks on open button")
	public void user_clicks_on_open_button() throws InterruptedException {

		WebElement openReviewQueueNameElement = driver.findElement(
				By.xpath("(//figcaption[text()='" + reviewQueueName + "']/../../following::td)[2]/ul/li[1]"));

		baseHelper.waitandclick(openReviewQueueNameElement);
	}

	@And("Update the ReviewQueue Name and Description")
	public void update_the_ReviewQueue_Name_and_Description(io.cucumber.datatable.DataTable dataTable)
			throws InterruptedException {
		List<java.util.Map<String, String>> data = dataTable.asMaps(String.class, String.class);

		for (int i = 0; i < data.size(); i++) {
			reviewQueueName = baseHelper.getRamdomString(data.get(0).get("UpdatedReviewQueueName"), 3);
			reviewQueueDesc = baseHelper.getRamdomString(data.get(0).get("UpdatedReviewQueueDescription"), 3);

			baseHelper.waitandclick(componentsReviewQueuesCreationPage.getUpdateReviewQueueName());
			actions.keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).build().perform();
			actions.sendKeys(Keys.BACK_SPACE).build().perform();
			actions.sendKeys(reviewQueueName).perform();
			actions.sendKeys(Keys.TAB).perform();

			WebElement updatedreviewQueueName = driver
					.findElement(By.cssSelector("div[class='inline edit name'] span[class='one-line']"));
			baseHelper.textToBePresentInElement(updatedreviewQueueName, reviewQueueName);
			Assert.assertEquals(updatedreviewQueueName.getText(), reviewQueueName);

			baseHelper.waitandclick(componentsReviewQueuesCreationPage.getUpdateReviewQueueDescription());
			actions.keyDown(Keys.CONTROL).sendKeys("a").keyUp(Keys.CONTROL).build().perform();
			actions.sendKeys(Keys.BACK_SPACE).build().perform();
			actions.sendKeys(reviewQueueDesc).perform();
			actions.sendKeys(Keys.TAB).perform();

			WebElement updatedreviewQueueDesc = driver
					.findElement(By.cssSelector("div[class='inline edit description'] span[class='one-line']"));
			baseHelper.textToBePresentInElement(updatedreviewQueueDesc, reviewQueueDesc);
			Assert.assertEquals(updatedreviewQueueDesc.getText(), reviewQueueDesc);

		}
		baseHelper.waitandclick(componentsReviewQueuesCreationPage.getBackIcon());

	}

	@And("User deletes Created ReviewQueue")
	public void user_deletes_Created_ReviewQueue() throws InterruptedException {
		Thread.sleep(5000);
		By deleteReviewQueueNameBy = By.xpath("//li[@data-name='" + reviewQueueName + "']");

		WebElement deleteReviewQueueNameElement = driver.findElement(deleteReviewQueueNameBy);

		String deleteReviewQueueMessage = "Are you sure you want to delete " + reviewQueueName
				+ "? This is a permanent action and it will no longer be unavailable for your entire organization.";

		baseHelper.visibilityOfElementLocated(deleteReviewQueueNameBy);
		baseHelper.waitandclick(deleteReviewQueueNameElement);

		baseHelper.textToBePresentInElement(componentsReviewQueuesListPage.getDeleteReviewQueueMessage(),
				deleteReviewQueueMessage);

		baseHelper.waitandclick(componentsReviewQueuesListPage.getDeleteOk());
		baseHelper.invisibilityOfElementLocated(deleteReviewQueueNameBy);

	}
	
	@Then("User enters the existing ReviewQueue Name and Description")
	public void user_enters_the_existing_ReviewQueue_Name_and_Description() {
		baseHelper.waitandclick(componentsReviewQueuesCreationPage.getReviewQueueName());
		actions.sendKeys(reviewQueueName).perform();

		baseHelper.waitandclick(componentsReviewQueuesCreationPage.getReviewQueueDescription());
		actions.sendKeys(reviewQueueDesc).perform();
	}

}
